$(document).ready(function(){
	
	
	
	
	$("#formulario").submit(function(){
	
		
		var usuario = {
		
			nombre: $('input[nombre="nombre"]').val()	
			
		};
		
		console.log(usuario);
	
	
		$.post($(this).attr("action"), usuario, function(response){
			
			
			console.log(response);
				
		});
	
	
	});
	
	
	
	
});